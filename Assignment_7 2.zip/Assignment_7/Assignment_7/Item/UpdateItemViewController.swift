//
//  UpdateItemViewController.swift
//  Assignment_7
//
//  Created by Gaurav Kohli on 11/5/22.
//

import UIKit

class UpdateItemViewController: UIViewController {
   
    var mainVC: MainViewController?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
